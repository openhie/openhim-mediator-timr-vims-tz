# openhim-mediator-timr-vims-tz
Connection Between Tanzania Immunization Registry and Vaccine Information Management System
